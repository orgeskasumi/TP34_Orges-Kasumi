#include <iostream>
#include <windows.h>

BOOL CALLBACK EnumWindowsProc(HWND hwnd, LPARAM lParam) {
    char windowTitle[256];

    // Searches and takes the window title to implement it 
    if (GetWindowTextA(hwnd, windowTitle, sizeof(windowTitle)) > 0) {
        // Checks if the window tiltw has Notepad in its name 
        if (strstr(windowTitle, "Notepad")) {
            *(HWND*)lParam = hwnd;
            return FALSE;  
        }
    }

    return TRUE; 
}

int main() {
    HWND notepadHandle = NULL;

    // Enumerates all windows to have Notepad on top`
    EnumWindows(EnumWindowsProc, (LPARAM)&notepadHandle);

    if (!notepadHandle) {
        std::cout << "Your Name isnt showing because your Notepad inst WORKING plzzz call a hacker :)." << std::endl;
        return 1;
    }

    // Makes the Notepad window stay on top of them
    SetWindowPos(notepadHandle, HWND_TOPMOST, 0, 0, 0, 0, SWP_NOMOVE | SWP_NOSIZE);

    std::cout << "your Name in notepad is pinned. Press Enter to unpin and exit." << std::endl;
    std::cin.get();

    // Remove the always-on-top setting when you are finished with it!!! ENJOY Orges Kasumi :)
    SetWindowPos(notepadHandle, HWND_NOTOPMOST, 0, 0, 0, 0, SWP_NOMOVE | SWP_NOSIZE);

    return 0;
}
